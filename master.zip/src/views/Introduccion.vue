<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in")            
      .col-lg-8
       p(data-aos="fade-down") La planificación y el control de proyectos son aspectos fundamentales en la gestión para alcanzar los resultados esperados. Estas actividades permiten establecer una técnica clara, optimizar la asignación de recursos y monitorear el progreso para garantizar que el proyecto se mantenga en camino y se logren los objetivos deseados.
        .bg-color-2.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/2.svg")
            .col-lg
              p.mb-0 En esta unidad, se explorarán diversas técnicas y herramientas utilizadas en la planificación y el control de proyectos, con un enfoque específico en el contexto del desarrollo de #[i software]. Se analizarán las diferencias entre los enfoques ágiles y tradicionales, se aprenderá a estimar tiempos y costos, y se desarrollará una comprensión sólida de la estructura de desglose del trabajo (WBS).

        p(data-aos="fade-down") Al finalizar esta unidad, se espera que se hayan adquirido las habilidades necesarias para diseñar planes de proyectos, considerando tiempo, recursos y costos. Se podrán aplicar técnicas de planificación y seguimiento, para optimizar el cumplimiento de los objetivos del proyecto. Estas competencias son esenciales para cualquier profesional que aspire a liderar o gestionar proyectos de #[i software] de manera eficiente.

    .row.mb-5
      .col-lg-8.mb-3.mb-lg-0  
        .bg-color-8.p-4.j1.mb-4(data-aos="fade-left")
          p.mb-0 Dominar la planificación y el control de proyectos, no solo permitirá entregar #[i software] de alta calidad dentro del presupuesto y en el plazo previsto, sino que también ayudará a adaptarse a los cambios, tomar decisiones informadas y comunicarse, de manera efectiva, con el equipo de trabajo y las partes interesadas. Estas habilidades son altamente valoradas en la industria del desarrollo de #[i software], por lo que pueden abrir puertas a roles de liderazgo y oportunidades de crecimiento profesional.
        p(data-aos="fade-down") La unidad se divide en tres temas principales:        
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/3.png", data-aos="zoom-in")

    .row.mb-5       
      .col-lg-4.mb-3.mb-lg-0 
        .bg-color-11.p-2.h-100(data-aos="fade-left")
          .row.align-items-center
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/4.svg")
            .col-lg
              h5 Tema 1
              p.mb-0 Técnicas de planificación.
      .col-lg-4.mb-3.mb-lg-0 
        .bg-color-11.p-2.h-100(data-aos="fade-down")
          .row.align-items-center
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/4.svg")
            .col-lg
              h5 Tema 2
              p.mb-0 Uso de diagramas de Gantt.
      .col-lg-4.mb-3.mb-lg-0 
        .bg-color-11.p-2.h-100(data-aos="fade-left")
          .row.align-items-center
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/4.svg")
            .col-lg
              h5 Tema 3
              p.mb-0 Seguimiento de kpis.                                    

    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0  
        figure
          img.img-a.img-t(src="@/assets/curso/temas/5.png", data-aos="zoom-in")    
      .col-lg-8
        p(data-aos="fade-down") Cada tema se explorará en profundidad, proporcionando conceptos teóricos, ejemplos prácticos y oportunidades para aplicar los conocimientos adquiridos. Se fomentará la participación a través de discusiones, ejercicios y estudios de casos.       

        .bg-color-2.p-5.j1(data-aos="fade-left")
          p.mb-0 Para aprovechar al máximo esta unidad, es importante tener una comprensión básica de los conceptos de gestión de proyectos y estar familiarizado con el ciclo de vida de la evolución del #[i software]. Con el estudio de esta unidad, se desarrollarán las habilidades y el conocimiento necesarios, para enfrentar los desafíos de la gestión de proyectos y liderar iniciativas exitosas del desarrollo de #[i software]. 

</template>
