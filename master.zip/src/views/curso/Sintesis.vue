<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up").mb-5 La Unidad 2: Planificación y control de proyectos, proporciona los conocimientos esenciales para planificar, ejecutar y controlar proyectos tecnológicos de manera efectiva. A través del estudio de metodologías, estructuras de desglose del trabajo (WBS) y herramientas de planificación, esta unidad permite comprender cómo organizar y gestionar recursos, tiempos y entregables. Este enfoque práctico y estratégico, garantiza que los estudiantes adquieran competencias claves para liderar con éxito proyectos de desarrollo de software en entornos reales.

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
