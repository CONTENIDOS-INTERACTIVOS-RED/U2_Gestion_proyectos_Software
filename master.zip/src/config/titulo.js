module.exports = 'Planificación y control de proyectos'
